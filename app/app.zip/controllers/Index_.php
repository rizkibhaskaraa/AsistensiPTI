<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index_ extends CI_Controller {

	function __construct() {
        parent::__construct();  
		$this->load->helper(array('form', 'url'));		
    }
	
	public function index()
	{	
		if(empty($_SESSION['validated'])){
			$this->login('');
		}
		else{		
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('dashboard');
		$this->load->view('footer');
		}	
	}
	
	
	public function data_nasabah(){
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('data_nasabah',$data);
		$this->load->view('footer');
	}
	public function add_nasabah(){
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$data['msg'] = ' ';
		$data['col'] = ' ';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('add_nasabah',$data);
		$this->load->view('footer');
	}
	public function tutupbuku(){
		$this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$query = $this->Model_all->data_nasabah();
		$pinjaman = array (
				0 =>'Pinjaman Jangka Pendek',
					'Pinjaman Jangka Menengah',				
					'Pinjaman Jangka Panjang',				
		);		
		foreach($query->result() as $db){
			for($i=0;$i<count($pinjaman);$i++){
					$kr = $this->Model_all->pinjam($db->nik,'kredit',$pinjaman[$i])->row();		
					$ang = $this->Model_all->pinjam($db->nik,'angsur',$pinjaman[$i])->row();	
					$this->Model_all->cek_bunga($db->nik,'pinjaman',$pinjaman[$i],$kr->value-$ang->value);
			}
		}
			
		$tabungan = array (
				0 =>    'Simpanan Wajib',
						'Simpanan Pokok',				
						'Simpanan Hari Raya',				
						'Simpanan Mana Suka'
		);
		foreach($query->result() as $db){
			for($i=0;$i<count($tabungan);$i++){
				
				$kr = $this->Model_all->tabungan($db->nik,'credit',$tabungan[$i])->row();		
				$ang = $this->Model_all->tabungan($db->nik,'debt',$tabungan[$i])->row();		
				$this->Model_all->cek_bunga($db->nik,'tabungan',$tabungan[$i],$kr->value-$ang->value);
			}
		}
		
		
	}
	public function add_nasabah_process(){
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		 $result = $this->Model_all->add_nasabah();
		 if($result){
			 $data['col'] = 'success';
			 $data['msg'] = 'SUKSES';
		 }
		 else {
			  $data['col'] = 'warning';
			  $data['msg'] = 'GAGAL, SUDAH ADA NIK YANG SAMA';
		 }
		  
		$this->load->model('Model_all');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('add_nasabah',$data);
		$this->load->view('footer');
	}
	public function ubah($nik){
		 $this->cek_sesi();  
		$data['col'] = '';
		$data['msg'] = '';
		$this->load->model('Model_all');
		$data['dbx'] = $this->Model_all->get_nasabah($nik)->row();
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('ubah',$data);
		$this->load->view('footer');
	}
	public function ubah_proses(){
		 $this->cek_sesi();  
		$nik = $this->security->xss_clean($this->input->post('nik'));
		$this->load->model('Model_all');
		 $result = $this->Model_all->ubah();
		 if($result){
			 $data['col'] = 'success';
			 $data['msg'] = 'SUKSES';
		 }
		 else {
			  $data['col'] = 'warning';
			  $data['msg'] = 'GAGAL, SUDAH ADA NIK YANG SAMA';
		 }
		  
		
		$data['dbx'] = $this->Model_all->get_nasabah($nik)->row();
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('ubah',$data);
		$this->load->view('footer');
	}
	
	public function pinjam_dana($mode){
		$this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$data['type'] = 'pinjam';
		$data['mode'] = $mode;
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('pinjam_dana',$data);
		$this->load->view('footer');
	}
	public function angsuran($mode){
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$data['type'] = 'angsur';
		$data['mode'] = $mode;
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('pinjam_dana',$data);
		$this->load->view('footer');
	}
	public function pinjam($mode,$nik){	
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		
		if($mode == 'pendek') $mode2 = 'Pinjaman Jangka Pendek';
		else if($mode == 'menengah') $mode2 = 'Pinjaman Jangka Menengah';
		else if($mode == 'panjang') $mode2 = 'Pinjaman Jangka Panjang';
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();
		
		
		
		$data['kredit'] = $this->Model_all->pinjam($nik,'kredit',$mode2)->row();		
		$data['angsuran'] = $this->Model_all->pinjam($nik,'angsur',$mode2)->row();
		
		$where = "nik='".$nik."' AND subjenis='".$mode2."' AND  (jenis_transaksi='kredit' OR jenis_transaksi='angsur' OR jenis_transaksi='potongan')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['nik'] = $nik;
		$data['col'] = '';
		$data['msg'] = '';
		$data['jenis'] = 'Pinjaman';
		$data['mode'] = $mode2;	
		$data['referer'] = $mode;		
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('pinjam',$data);
		$this->load->view('footer');
	}
	public function angsur($mode,$nik){	
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		
		if($mode == 'pendek') $mode2 = 'Pinjaman Jangka Pendek';
		else if($mode == 'menengah') $mode2 = 'Pinjaman Jangka Menengah';
		else if($mode == 'panjang') $mode2 = 'Pinjaman Jangka Panjang';
		
		
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();	
		
		
		
		$data['kredit'] = $this->Model_all->pinjam($nik,'kredit',$mode2)->row();		
		$data['angsuran'] = $this->Model_all->pinjam($nik,'angsur',$mode2)->row();
		$where = "nik='".$nik."' AND subjenis='".$mode2."' AND (jenis_transaksi='kredit' OR jenis_transaksi='angsur' OR jenis_transaksi='potongan')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['nik'] = $nik;
		$data['col'] = '';
		$data['msg'] = '';
		$data['jenis'] = 'Angsuran';
		$data['mode'] = $mode2;	
		$data['referer'] = $mode;
		
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('pinjam',$data);
		$this->load->view('footer');
	}
	
	public function setoran($mode){
		 $this->cek_sesi();  
		 $data['mode'] = $mode;
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$data['type'] = 'setor';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('simpanan',$data);
		$this->load->view('footer');
	}
	
	public function penarikan($mode){
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$data['type'] = 'penarik';
		$data['mode'] = $mode;
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('simpanan',$data);
		$this->load->view('footer');
	}
	public function diasetoran(){
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$data['type'] = 'credit';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('simp_dia',$data);
		$this->load->view('footer');
	}
	public function diadebt(){
		$this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['dbx'] = $this->Model_all->data_nasabah();
		$data['type'] = 'debet';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('simp_dia',$data);
		$this->load->view('footer');
	}
	public function debet($nik){
		  $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();

		$data['kredit']   = $this->Model_all->tabungan($nik,'credit','diakonia')->row();		
		$data['angsuran'] = $this->Model_all->tabungan($nik,'debt','diakonia')->row();
		$where = "nik='".$nik."' AND subjenis='diakonia' AND (jenis_transaksi='credit' OR jenis_transaksi='debt')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['nik'] = $nik;
		$data['col'] = '';
		$data['msg'] = '';
		$data['jenis'] = 'debt';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('diakonia',$data);
		$this->load->view('footer');
	}
	public function credit($nik){
		  $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();
		
		$data['kredit'] = $this->Model_all->tabungan($nik,'credit','diakonia')->row();		
		$data['angsuran'] = $this->Model_all->tabungan($nik,'debt','diakonia')->row();
		
		$where = "nik='".$nik."' AND subjenis='diakonia'  AND (jenis_transaksi='credit' OR jenis_transaksi='debt')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['nik'] = $nik;
		$data['col'] = '';
		$data['msg'] = '';
		$data['jenis'] = 'credit';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('diakonia',$data);
		$this->load->view('footer');
	}
	public function dia_proses(){		
		$this->load->model('Model_all');
		 $this->cek_sesi();  
		$result = $this->Model_all->kredit();
		 if($result){
			 $data['col'] = 'success';
			 $data['msg'] = 'Sukses';
		 }
		 else {
			  $data['col'] = 'warning';
			  $data['msg'] = 'GAGAL';
		 }
		 
		$nik = $this->security->xss_clean($this->input->post('nik'));
		$jenis = $this->security->xss_clean($this->input->post('jenis'));
		$subjenis = $this->security->xss_clean($this->input->post('subjenis'));
		$referer = $this->security->xss_clean($this->input->post('referer'));
		
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();
		$this->db->where('jenis_transaksi','credit');	
		$this->db->where('subjenis',$subjenis);		
		$data['kredit'] = $this->Model_all->tabungan($nik,'credit',$subjenis)->row();
		$this->db->where('jenis_transaksi','debt');
		$this->db->where('subjenis','diakonia');	
		$data['angsuran'] = $this->Model_all->tabungan($nik,'debt',$subjenis)->row();
		
		$where = "nik='".$nik."' AND subjenis='diakonia' AND (jenis_transaksi='credit' OR jenis_transaksi='debt')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['nik'] = $nik;
		$jenis_transaksi = $this->security->xss_clean($this->input->post('jenis'));
		
		$data['jenis'] = $jenis_transaksi;
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('diakonia',$data);
		$this->load->view('footer');
	}
	public function setor($mode,$nik){	
		$this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();
		
		if($mode == 'wajib') $mode2 = 'Simpanan Wajib';
		else if($mode == 'pokok') $mode2 = 'Simpanan Pokok';
		else if($mode == 'hari_raya') $mode2 = 'Simpanan Hari Raya';
		else if($mode == 'mana_suka') $mode2 = 'Simpanan Mana Suka';
		
		
		
		$data['kredit'] = $this->Model_all->tabungan($nik,'credit',$mode2)->row();		
		$data['angsuran'] = $this->Model_all->tabungan($nik,'debt',$mode2)->row();
		
		$where = "nik='".$nik."' AND  subjenis = '".$mode2."' AND (jenis_transaksi='credit' OR jenis_transaksi='debt')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['mode'] = $mode2;
		$data['referer'] = $mode;
		$data['nik'] = $nik;
		$data['col'] = '';
		$data['msg'] = '';
		$data['jenis'] = 'credit';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('tabungan',$data);
		$this->load->view('footer');
	}
	public function penarik($mode,$nik){	
		 $this->cek_sesi();  
		$this->load->model('Model_all');
		$this->db->where('status', 'AKTIF');
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();
		
		if($mode == 'wajib') $mode2 = 'Simpanan Wajib';
		else if($mode == 'pokok') $mode2 = 'Simpanan Pokok';
		else if($mode == 'hari_raya') $mode2 = 'Simpanan Hari Raya';
		else if($mode == 'mana_suka') $mode2 = 'Simpanan Mana Suka';
		
		
		
		
		$data['kredit'] = $this->Model_all->tabungan($nik,'credit',$mode2)->row();		
		$data['angsuran'] = $this->Model_all->tabungan($nik,'debt',$mode2)->row();
		
		$where = "nik='".$nik."' AND  subjenis = '".$mode2."' AND (jenis_transaksi='credit' OR jenis_transaksi='debt')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['nik'] = $nik;
		$data['col'] = '';
		$data['msg'] = '';
		$data['mode'] = $mode2;
	
		$data['referer'] = $mode;
		$data['jenis'] = 'debt';
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('tabungan',$data);
		$this->load->view('footer');
	}
	public function tab_proses(){		
		$this->load->model('Model_all');
		 $this->cek_sesi();  
		$result = $this->Model_all->kredit();
		 if($result){
			 $data['col'] = 'success';
			 $data['msg'] = 'Sukses';
		 }
		 else {
			  $data['col'] = 'warning';
			  $data['msg'] = 'GAGAL';
		 }
		 		 
		$nik = $this->security->xss_clean($this->input->post('nik'));
		$jenis = $this->security->xss_clean($this->input->post('jenis'));
		$subjenis = $this->security->xss_clean($this->input->post('subjenis'));
		$referer = $this->security->xss_clean($this->input->post('referer'));
		
		$data['data'] = $this->Model_all->get_nasabah($nik)->row();
		$this->db->where('jenis_transaksi','credit');	
		$this->db->where('subjenis',$subjenis);		
		$data['kredit'] = $this->Model_all->tabungan($nik,'credit',$subjenis)->row();
		
		$data['angsuran'] = $this->Model_all->tabungan($nik,'debt',$subjenis)->row();
		$where = "nik='".$nik."' AND  subjenis = '".$subjenis."' AND (jenis_transaksi='credit' OR jenis_transaksi='debt')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();
		$data['nik'] = $nik;
		$data['mode'] = $subjenis;
		$data['referer'] = $referer;
		$jenis_transaksi = $this->security->xss_clean($this->input->post('jenis'));
		
		$data['jenis'] = $jenis_transaksi;
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('tabungan',$data);
		$this->load->view('footer');
	}
	public function pinjam_proses(){		
		$this->load->model('Model_all');
		 $this->cek_sesi();  
		$result = $this->Model_all->kredit();
		 if($result){
			 $data['col'] = 'success';
			 $data['msg'] = 'Sukses';
		 }
		 else {
			  $data['col'] = 'warning';
			  $data['msg'] = 'GAGAL';
		 }
		 
		$nik = $this->security->xss_clean($this->input->post('nik'));
		$jenis = $this->security->xss_clean($this->input->post('jenis'));
		$subjenis = $this->security->xss_clean($this->input->post('subjenis'));
		$referer = $this->security->xss_clean($this->input->post('referer'));

		$data['data'] = $this->Model_all->get_nasabah($nik)->row();				
		$data['kredit'] = $this->Model_all->pinjam($nik,'kredit',$subjenis)->row();		
		$data['angsuran'] = $this->Model_all->pinjam($nik,'angsur',$subjenis)->row();
		
		$where = "nik='".$nik."' AND subjenis='".$subjenis."' AND (jenis_transaksi='kredit' OR jenis_transaksi='angsur' OR jenis_transaksi='potongan')";
		$this->db->where($where);
		$data['db'] = $this->Model_all->transaksi();		
		$data['nik'] = $nik;
		$data['mode'] = $subjenis;
		$data['referer'] = $referer;
		$jenis_transaksi = $this->security->xss_clean($this->input->post('jenis'));
		if($jenis_transaksi == 'kredit') $je_nis = 'Pinjaman';
		else  $je_nis = 'Angsuran';
		$data['jenis'] = $je_nis;
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('pinjam',$data);
		$this->load->view('footer');
	}
	public function login($msg){
		$data['msg'] = $msg;
		$this->load->view('login',$data);			
	}
	 public function logout() {
		 $this->cek_sesi();  
		 $this->session->sess_destroy();
         $this->index('','login');
		 redirect('');
	 }
	  public function cek_sesi (){	
		 if (empty($_SESSION['validated'])) 
		 redirect(''); 
	}
	public function process(){
		$this->load->model('mdl_login');        
        $result = $this->mdl_login->validate();
		 if(! $result){
            
            $msg = '<font color=red>Invalid username and/or password.</font><br />';
            $this->index($msg);
        }else{
            redirect('');
        }        
	 }
	
}
