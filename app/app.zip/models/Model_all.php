<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* Author: Digitronika.com
 * Description: Login model class
 */
class Model_all extends CI_Model{
    function __construct(){
        parent::__construct();
    }
	
	
	public function data_nasabah(){
		$query = $this->db->get('nasabah');		
		return $query;	
	}
	public function get_nasabah($nik){
		$this->db->where('nik', $nik);
		$query = $this->db->get('nasabah');		
		return $query;	
	}
	public function pinjam($nik,$jenis,$subjenis){
		
		$this->db->where('nik', $nik);
		$this->db->where('jenis_transaksi',$jenis);	
		$this->db->where('subjenis',$subjenis);		
		$this->db->select('*,sum(value+0) as value');		
		$query = $this->db->get('transaksi');		
		return $query;	
	}
	public function cek_bunga($nik,$jenis,$subjenis,$saldo){
		
		$cur = (new \DateTime())->format('d');
		$dmax = (new \DateTime())->format( 't' );
		if($cur <4){
			$max_d = (new \DateTime())->format( 'Y-m-t' );				
			$max_dx = date('Y-m-d', strtotime($max_d. ' - 1 months'));
		}
		else $max_dx =(new \DateTime())->format( 'Y-m-t' );
		
		$max_d = (new \DateTime())->format( 'Y-m-t' );		
		$range_d3 = date('Y-m-d', strtotime($max_dx. ' + 3 days'));
		if($cur == $dmax || $cur == 1 || $cur == 2 || $cur == 3 ){
			$where = " nik='".$nik."' AND subjenis='".$subjenis."'  AND (keterangan='Bunga: 0.75%' OR keterangan='Bunga: 1.5%') AND tgl_transaksi BETWEEN '".$max_dx." 00:00:00.00' AND '".$range_d3." 23:59:59.999' ";
			$this->db->where($where);
			$query = $this->db->get('transaksi');
				
			if( $query->num_rows() == 0){
				echo $saldo.'-';
				if($saldo !=0){
					if($jenis == 'pinjaman' ){
						$bunga =  $saldo * 0.015;			
							$data = array(			
							'nik'=>$nik,
							'jenis_transaksi'=>'kredit',
							'subjenis'=>$subjenis,
							'keterangan'=>'Bunga: 1.5%',	
							'value'=>$bunga						
						);
						
						$this->db->insert('transaksi',$data);
					}
					else if( $jenis == 'tabungan' ){
						$bunga =  $saldo * 0.0075;			
							$data = array(			
							'nik'=>$nik,
							'jenis_transaksi'=>'credit',
							'subjenis'=>$subjenis,
							'keterangan'=>'Bunga: 0.75%',	
							'value'=>$bunga						
						);
						
						$this->db->insert('transaksi',$data);
					}
				}
			}
		}
		$this->load->helper('url');
		echo ' <script> alert(" Tutup Buku Sudah dilakukan, Pemberian Bunga Pinjaman dan Bunga tabungan Sudah diberikan ke nasabah");  </script> ';
		redirect('/index_', 'refresh');
		
	}
	public function tabungan($nik,$jenis,$subjenis){
		$this->db->where('nik', $nik);
		$this->db->where('jenis_transaksi',$jenis);	
		$this->db->where('subjenis',$subjenis);		
		$this->db->select('*,sum(value+0) as value');		
		$query = $this->db->get('transaksi');		
		return $query;	
	}
	public function tabungan2($nik){
		$this->db->where('nik', $nik);
			
		$this->db->select('*,sum(value+0) as value');		
		$query = $this->db->get('transaksi');		
		return $query;	
	}
	public function transaksi(){
		
		$query = $this->db->get('transaksi');		
		return $query;	
	}
	public function ubah(){
		$nik = $this->security->xss_clean($this->input->post('nik'));
        $nama = $this->security->xss_clean($this->input->post('nama'));
		$alamat = $this->security->xss_clean($this->input->post('alamat'));
        $telp = $this->security->xss_clean($this->input->post('telp'));
		$status = $this->security->xss_clean($this->input->post('status'));
		$data = array(
			'nama'=>$nama,			
			'alamat'=>$alamat,
			'status'=>$status,
			'no_telp'=>$telp
		 );
		$this->db->where('nik', $nik);
		$query = $this->db->update('nasabah',$data);		
		return $query;	
	}
	public function add_nasabah(){
		$nik = $this->security->xss_clean($this->input->post('nik'));
        $nama = $this->security->xss_clean($this->input->post('nama'));
		$alamat = $this->security->xss_clean($this->input->post('alamat'));
        $telp = $this->security->xss_clean($this->input->post('telp'));
		
		
		$this->db->where('nik', $nik);
		$query = $this->db->get('nasabah');		
		
		if($query->num_rows ==0){			
		
		 $data = array(
			'nama'=>$nama,
			'nik'=>$nik,
			'alamat'=>$alamat,
			'status'=>'AKTIF',
			'no_telp'=>$telp
		 );
		$this->db->insert('nasabah',$data);
		return true;
		}
		else {
			return false;
		}
	}
	public function kredit(){
		$nik = $this->security->xss_clean($this->input->post('nik'));
		$value = str_replace(",", "", $this->input->post('nilai'));
		$jenis_transaksi = $this->security->xss_clean($this->input->post('jenis'));		
		$subjenis = $this->security->xss_clean($this->input->post('subjenis'));				
	
		 $data = array(			
			'nik'=>$nik,
			'jenis_transaksi'=>$jenis_transaksi,
			'subjenis'=>$subjenis,	
			'value'=>$value
		 );
		$this->db->insert('transaksi',$data);
		
		
		if($jenis_transaksi == 'kredit'){
			$value2 = $value * 0.01;			
			$data = array(			
			'nik'=>$nik,
			'jenis_transaksi'=>'potongan',
			'subjenis'=>$subjenis,
			'keterangan'=>'Resiko Kredit 1%',	
			'value'=>$value2
		 );
		 $this->db->insert('transaksi',$data);
		 $value3 =  $value * 0.01;	
			$diterima = $value - $value * 0.02;	
			$data = array(			
			'nik'=>$nik,
			'jenis_transaksi'=>'potongan',
			'subjenis'=>$subjenis,
			'keterangan'=>'Profesi 1%: Diterima= Rp.'.number_format( $diterima ,0,",","."),	
			'value'=>$value3
		 );
		 $this->db->insert('transaksi',$data);
		 
		}
		return true;
		
	}
}
?>