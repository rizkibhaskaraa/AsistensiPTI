<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* Author: Digitronika.com
 * Description: Login model class
 */
class Mdl_login extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    
    public function validate(){
        // grab user input
        $username = $this->security->xss_clean($this->input->post('nik'));
        $password = $this->security->xss_clean($this->input->post('pass'));
        
        // Prep the query
        
		
		$where = "user_id='".$username."' AND pass='".md5($password)."'";
		$this->db->where($where);
        
        // Run the query
        $query = $this->db->get('admin');
		
        // Let's check if there are any results
        if($query->num_rows == 1)
        {
            // If there is a user, then create session data
            $row = $query->row();
            $data = array(
                    'id' => $row->id,
                    'telp' => $row->telp,                   
                    'username' => $row->user_id,															
                    'validated' => true
                    );
            $this->session->set_userdata($data);
            return true;
        }		
      
        return false;
    }
	
	public function updAkun(){
		$username  = $this->security->xss_clean($this->input->post('user'));
        $password  = $this->security->xss_clean($this->input->post('pass_lama'));
		$pass_baru = $this->security->xss_clean($this->input->post('pass_baru'));
		$telp 	   = $this->security->xss_clean($this->input->post('telp'));
		
		
		if(empty ($pass_baru)){
				$data = array(					
					'email'  => $telp					
				); 				
				$this->db->where('user', $_SESSION['username']);
				$this->db->update('users', $data);
		}
		else{
				if($_SESSION['level']=='kabupaten'){
					$data = array();
					$data = array( 'pass2'  => md5($pass_baru)	);
					$this->db->where('nama_kab', $_SESSION['lokasi']);	
					$this->db->update('users', $data);
					$data   = array(
					'pass'  => md5($pass_baru)						
					);
					$this->db->where('user', $_SESSION['username']);
					$this->db->update('users', $data);
				}
				else {
					$data   = array(
					'pass'  => md5($pass_baru),
					'profile_photo'  => $photo				
					);		
						$this->db->where('user', $_SESSION['username']);
						$this->db->update('users', $data);
				}
				
		}
			
	}
	public function addAkun(){
		$username = $this->security->xss_clean($this->input->post('user'));
        $password = $this->security->xss_clean($this->input->post('pass_baru'));
		$jabatan = $this->security->xss_clean($this->input->post('jabatan'));
		$lokasi = $this->security->xss_clean($this->input->post('lokasi'));
        $email = $this->security->xss_clean($this->input->post('email'));
				
		if(empty ($username)|| empty ($password) || empty ($lokasi)||empty ($email)){
			
			return false;
		}
		else{
			$this->db->where('user', $username);
			$this->db->where('pass', md5($password));
			$query = $this->db->get('users');
			if($jabatan == 'kabupaten')
				$nama_kab = $lokasi;
			else if($jabatan == 'provinsi')
				$nama_kab = '';
			else if($jabatan == 'kecamatan') 
				$nama_kab = $_SESSION['kabupaten'];
			
			$photo = $_SESSION['photo'];		
			
			if($query->num_rows == 0)
			{		
					$data = array(
					'user'  => $username,
					'level'  => $jabatan,
					'lokasi'  => $lokasi,
					'email'  => $email,
					'profile_photo' => $photo,
					'nama_kab'  => $nama_kab,
					'pass'  => md5($password)					
				);
							
				$this->db->insert('users', $data);
			}
			else { return false; }
		}
		return true;	
	}
	
	public function delAkun(){
	  $username = $this->security->xss_clean($this->input->post('userx'));
        
	  $this -> db -> where('user',$username );
	  $this -> db -> delete('users');
	  
	  return true;
			
	}
}
?>