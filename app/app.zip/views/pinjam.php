<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Data Nasabah - Pinjaman
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> </h3>
            </div>
			<div class="alert alert-<?php echo $col; ?>">
			 <?php echo $msg; ?>
			</div>
			<div class="box-body">
               <form id="form" action="<?php echo base_url('index_/pinjam_proses'); ?>" method="post" role="form">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Jumlah <?php echo $jenis; ?></label>
                  <input type="text" class="form-control input-lg"  id="myID" name="nilai" value="" placeholder="0">
                </div>
				<?php if($jenis == 'Pinjaman') $je_nis ='kredit';
					  else $je_nis = 'angsur' ; ?>
                <input name="nik" value=<?php echo $nik; ?> type="hidden">
				<input name="jenis" value="<?php echo $je_nis; ?>" type="hidden">
				<input name="subjenis" value="<?php echo $mode; ?>" type="hidden">
					
			  
			 </div>
			  
              <!-- /.box-body -->
		
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
        </div> 
            <!-- /.box-header -->
            <div class="box-body">
			
              <table  class="table table-bordered table-hover">
               <thead >
			  
                <tr>
                	<th style="text-align: left; width:15%"  rowspan="1">Nama Nasabah</th>
                	<th style="text-align: left; width:15%" colspan="1">NIK</th>
					<th style="text-align: left; width:15%" colspan="1"> Kredit</th>	
					<th style="text-align: left; width:15%" colspan="1"> Angsuran</th>	
					<th style="text-align: left; width:15%" colspan="1">Total</th>					
                </tr>
                	
            </thead>
                <tbody style="text-align: left;">
               <?php
				   $no=0;
			  
						echo '<tr><td>'
						 
						 .$data->nama.'</td><td>'
						 .$data->nik .'</td><td>Rp. '
						  .number_format( $kredit->value	,2,",",".")	.'</td><td> Rp. '
						 .number_format( $angsuran->value	,2,",",".")	.'</td><td> Rp. '
						 
						 .number_format( $kredit->value*(-1) + $angsuran->value	,2,",",".")					 
						 .'</td></tr>';
			   
			   ?>
				 
                </tbody>
                
              </table>
            
            <!-- /.box-body -->
          </div>
		  <div class="box-body">
			
              <table  class="table table-bordered table-hover">
               <thead >
			  
                <tr>
                	<th style="text-align: left; width:5%"  rowspan="1">No</th>
					<th style="text-align: left; width:15%" colspan="1">Waktu Transaksi</th>
                	<th style="text-align: left; width:10%" colspan="1">Jenis Transaksi</th>
					<th style="text-align: left; width:20%" colspan="1">Jenis Pinjaman</th>
					<th style="text-align: left; width:15%" colspan="1">Jumlah</th>	
					<th style="text-align: left; width:15%" colspan="1">Total Pinjaman</th>	
					<th style="text-align: left; width:15%" colspan="1">Keterangan</th>				
                </tr>
                	
            </thead>
                <tbody style="text-align: left;">
               <?php
				   $no=0;$saldo = 0;
				foreach($db->result() as $dbx){
					$no++;
					if($dbx->jenis_transaksi == 'kredit')
						$saldo = $saldo + $dbx->value;
					elseif($dbx->jenis_transaksi == 'angsur')
						$saldo = $saldo - $dbx->value;
						echo '<tr><td>'
						 .$no.'</td><td>' 
						 .$dbx->tgl_transaksi.'</td><td>'
						 .$dbx->jenis_transaksi .'</td><td>'
						 .$dbx->subjenis .'</td><td>Rp. '
						 .number_format( $dbx->value ,2,",",".")	.'</td><td> Rp. '	
						 .number_format( $saldo	,2,",",".")	.'</td><td>'			
						 .$dbx->keterangan			 
						 .'</td></tr>';
				}
			   ?>
				 
                </tbody>
                
              </table>
            
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
	
          </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
