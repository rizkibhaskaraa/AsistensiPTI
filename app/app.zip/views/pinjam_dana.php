<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Data Nasabah  - <?php echo ucfirst($type).'an'; ?>
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			<div style="overflow-x:scroll; width: auto; white-space:nowrap;" class="box box-success table-responsive">
              <table id="example1" class="table table-bordered table-hover">
               <thead >
			  
                <tr><th style="text-align: left; width:2%" rowspan="1">No</th>
                	<th style="text-align: left; width:15%"  rowspan="1">Nama Nasabah</th>
                	<th style="text-align: left; width:15%" colspan="1">NIK</th>
                    <th style="text-align: left; width:15%" colspan="1">Alamat</th>
					<th style="text-align: left; width:15%" colspan="1">Telp</th>	
					
										
                </tr>
                	
            </thead>
                <tbody style="text-align: left;">
               <?php
				   $no=0;
			   foreach($dbx->result() as $data){
				   $no++;
						echo '<tr><td>'
						 .$no.'</td><td><a href="'.base_url().'index_/'.$type.'/'.$mode.'/'.$data->nik.'" >'
						 .$data->nama.'</a></td><td>'
						 .$data->nik .'</td><td>'
						  .$data->alamat.'</td><td>'
						
						 .$data->no_telp						 
						 .'</td></tr>';
			   }
			   ?>
				
                 
                </tbody>
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
        </div> </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>