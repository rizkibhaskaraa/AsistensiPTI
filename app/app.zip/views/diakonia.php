<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Data Nasabah - Diakonia
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"> </h3>
            </div>
			<?php if (!empty($msg)){
			echo '<div class="alert alert-'.$col.'">'.$msg.'
			</div>';
			}
			?>
			<div class="box-body">
               <form id="form"  action="<?php echo base_url('index_/dia_proses'); ?>" method="post" role="form">
              <div class="box-body">
                <div class="form-group">
				<?php 
				if($jenis == 'credit') $je_nis = 'Setoran';
				else  $je_nis = 'Penarikan'; ?>
                  <label for="exampleInputEmail1">Jumlah <?php echo ucfirst($je_nis); ?></label>
                  <input type="text" class="form-control input-lg" id="myID" name="nilai" value="" placeholder="0">
                </div>
				
                <input name="nik" value=<?php echo $nik; ?> type="hidden">
				<input name="jenis" value=<?php echo $jenis; ?> type="hidden">
				<input name="subjenis" value='diakonia' type="hidden">
					
				
              </div>
              <!-- /.box-body -->
		
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
        </div> 
            <!-- /.box-header -->
            <div class="box-body">
			
              <table  class="table table-bordered table-hover">
               <thead >
			  
                <tr>
                	<th style="text-align: left; width:15%"  rowspan="1">Nama Nasabah</th>
                	<th style="text-align: left; width:15%" colspan="1">NIK</th>
					<th style="text-align: left; width:15%" colspan="1"> Tabungan</th>	
					<th style="text-align: left; width:15%" colspan="1"> Penarikan</th>	
					<th style="text-align: left; width:15%" colspan="1">Saldo Tabungan</th>					
                </tr>
                	
            </thead>
                <tbody style="text-align: left;">
               <?php
				   $no=0;
			  
						echo '<tr><td>'
						 
						 .$data->nama.'</td><td>'
						 .$data->nik .'</td><td>Rp. '
						 .number_format( $kredit->value	,2,",",".")	.'</td><td> Rp. '
						 .number_format( $angsuran->value	,2,",",".")	.'</td><td> Rp. '						 
						 .number_format( $kredit->value - $angsuran->value	,2,",",".")				 
						 .'</td></tr>';
			   
			   ?>
				 
                </tbody>
                
              </table>
            
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
			<div class="box-body">
			
              <table  class="table table-bordered table-hover">
               <thead >
			  
                <tr>
                	<th style="text-align: left; width:5%"  rowspan="1">No</th>
					<th style="text-align: left; width:15%" colspan="1">Waktu Transaksi</th>
                	<th style="text-align: left; width:15%" colspan="1">Jenis Transaksi</th>
					<th style="text-align: left; width:15%" colspan="1">Jenis Simpanan</th>
					<th style="text-align: left; width:15%" colspan="1">Keterangan</th>	
					<th style="text-align: left; width:15%" colspan="1">Jumlah</th>	
					<th style="text-align: left; width:15%" colspan="1">Saldo</th>	
					
								
                </tr>
                	
            </thead>
                <tbody style="text-align: left;">
               <?php
				   $no=0;$saldo = 0;
				foreach($db->result() as $dbx){
					$no++;
					if($dbx->jenis_transaksi == 'credit')
						$saldo = $saldo + $dbx->value;
					elseif($dbx->jenis_transaksi == 'debt')
						$saldo = $saldo - $dbx->value;
						echo '<tr><td>'
						 .$no.'</td><td>' 
						 .$dbx->tgl_transaksi.'</td><td>'
						 .$dbx->jenis_transaksi .'</td><td>'
						  .$dbx->subjenis .'</td><td>'
						  .$dbx->keterangan .'</td><td>Rp. '
						 .number_format( $dbx->value ,2,",",".")	.'</td><td> Rp. '						 				 
						 .number_format( $saldo	,2,",",".")					 
						 .'</td></tr>';
				}
			   ?>
				 
                </tbody>
                
              </table>
            
            <!-- /.box-body -->
          </div>
          </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>