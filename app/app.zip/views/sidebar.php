<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      
      <!-- search form -->
     
   
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
		<li >  . </li>
		<?php 
		
		$cur = (new \DateTime())->format('d');
		$max_d =(new \DateTime())->format( 't' );			
		if($cur == $max_d || $cur == 1 || $cur == 2 || $cur == 3 ): ?>
		<li >
          <a href="<?php echo base_url(); ?>index_/tutupbuku">
            <i class="fa  fa-cc-amex"></i> <span>Tutup Buku Bulanan</span>
          </a>          
        </li>
		<?php endif; ?>
		<li >
          <a href="<?php echo base_url(); ?>">
            <i class="fa  fa-dashboard"></i> <span>Dashboard</span>
          </a>          
        </li>
		<li class="treeview">		  
          <a href="#">
            <i class="fa fa-users"></i>
            <span>Nasabah</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
			  <ul class="treeview-menu">
				<li class="active"><a href="<?php echo base_url(); ?>index_/data_nasabah"><i class="fa fa-circle-o"></i> Data Nasabah</a></li>
				<li class="active"><a href="<?php echo base_url(); ?>index_/add_nasabah"><i class="fa fa-circle-o"></i> Tambah Nasabah</a></li>			
			  </ul>
		  </li>
		<li class="treeview">		  
          <a href="#">
            <i class="fa fa-credit-card"></i>
            <span>Kredit</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
			  <ul class="treeview-menu">
			    <li class="active"><a href="#"><i class="fa  fa-arrow-circle-right  "></i>Jangka Pendek (5 Bulan)</a>
					<ul class="treeview-menu">
						<li class="active"><a href="<?php echo base_url(); ?>index_/pinjam_dana/pendek"><i class="fa fa-circle-o"></i>Pinjam Dana</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>index_/angsuran/pendek"><i class="fa fa-circle-o"></i>Bayar Angsuran</a></li>			
				    </ul>				
				</li>
				<li class="active"><a href="#"><i class="fa  fa-arrow-circle-right  "></i>Jangka Menengah (10 Bulan)</a>
					<ul class="treeview-menu">
						<li class="active"><a href="<?php echo base_url(); ?>index_/pinjam_dana/menengah"><i class="fa fa-circle-o"></i>Pinjam Dana</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>index_/angsuran/menengah"><i class="fa fa-circle-o"></i>Bayar Angsuran</a></li>			
				    </ul>				
				</li>
				<li class="active"><a href="#"><i class="fa  fa-arrow-circle-right  "></i>Jangka Panjang (20 Bulan)</a>
					<ul class="treeview-menu">
						<li class="active"><a href="<?php echo base_url(); ?>index_/pinjam_dana/panjang"><i class="fa fa-circle-o"></i>Pinjam Dana</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>index_/angsuran/panjang"><i class="fa fa-circle-o"></i>Bayar Angsuran</a></li>			
				    </ul>				
				</li>
			  </ul>
		  </li>
		
		<li class="treeview">		  
          <a href="#">
            <i class="fa fa-money"></i>
            <span>Simpanan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
			  <ul class="treeview-menu">
				<li class="active"><a href="#"><i class="fa  fa-arrow-circle-right  "></i>Simpanan Wajib</a>
					<ul class="treeview-menu">
						<li class="active"><a href="<?php echo base_url(); ?>index_/setoran/wajib"><i class="fa fa-circle-o"></i>Setoran</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>index_/penarikan/wajib"><i class="fa fa-circle-o"></i>Penarikan</a></li>			
				    </ul>				
				</li>
				
				<li class="active"><a href="#"><i class="fa  fa-arrow-circle-right  "></i>Simpanan Pokok</a>
					<ul class="treeview-menu">
						<li class="active"><a href="<?php echo base_url(); ?>index_/setoran/pokok"><i class="fa fa-circle-o"></i>Setoran</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>index_/penarikan/pokok"><i class="fa fa-circle-o"></i>Penarikan</a></li>			
				    </ul>				
				</li>
				
				<li class="active"><a href="#"><i class="fa  fa-arrow-circle-right  "></i>Simpanan Hari Raya</a>
					<ul class="treeview-menu">
						<li class="active"><a href="<?php echo base_url(); ?>index_/setoran/hari_raya"><i class="fa fa-circle-o"></i>Setoran</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>index_/penarikan/hari_raya"><i class="fa fa-circle-o"></i>Penarikan</a></li>			
				    </ul>				
				</li>
				
				<li class="active"><a href="#"><i class="fa  fa-arrow-circle-right  "></i>Simpanan Mana Suka</a>
					<ul class="treeview-menu">
						<li class="active"><a href="<?php echo base_url(); ?>index_/setoran/mana_suka"><i class="fa fa-circle-o"></i>Setoran</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>index_/penarikan/mana_suka"><i class="fa fa-circle-o"></i>Penarikan</a></li>			
				    </ul>				
				</li>
			  </ul>
		  </li>
		  <li class="treeview">		  
          <a href="#">
            <i class="fa fa-money"></i>
            <span>Diakonia</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
			  <ul class="treeview-menu">
				<li class="active"><a href="<?php echo base_url(); ?>index_/diasetoran"><i class="fa fa-circle-o"></i> Setoran</a></li>
				<li class="active"><a href="<?php echo base_url(); ?>index_/diadebt"><i class="fa fa-circle-o"></i> Penarikan</a></li>			
			  </ul>
		  </li>
		  
		  
		  
     
	  </ul>
    </section>
    <!-- /.sidebar -->
  </aside>