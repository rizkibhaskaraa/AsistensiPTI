 
 <!-- Left side column. contains the logo and sidebar -->
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    
    
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
	   <div style="align:center;" class="row">
	   <center> <h2>
		
        PRA KOPERASI DIAKONIA</br>
		"KURNIA ASIH"</br>
		GEREJA KRISTEN JAWA TANON        </br>
		 <img src="<?php echo base_url().'img/koperasi.png' ; ?>" height="420" > 
      </h2></center>
			
			 
		</div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  

